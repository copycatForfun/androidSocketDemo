package com.yzq.socketdemo.common;

/**
 * 存放一些常量
 */

public class Constants {

    /*intent tag*/
    public static final String INTENT_IP="intentIp";//ip
    public static final String INTENT_PORT="intentPort";//port(端口号)


    /*EventBus  msg*/
    public static final String CONNET_SUCCESS="connectSucccess";
}
