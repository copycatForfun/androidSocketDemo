package com.yzq.socketdemo.common;

/**
 * 传递消息时使用，可以自己增加更多的参数
 */

public class EventMsg {

    private String Tag;


    public String getTag() {
        return Tag;
    }

    public void setTag(String tag) {
        Tag = tag;
    }
}
